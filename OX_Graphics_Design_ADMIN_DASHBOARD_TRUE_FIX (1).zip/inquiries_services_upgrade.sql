-- OX Graphics Design: design inquiries, OX-AI website briefs, and admin-managed services
create extension if not exists pgcrypto;
create table if not exists public.design_inquiries (
 id uuid primary key default gen_random_uuid(), client_id uuid not null references public.client_profiles(user_id) on delete cascade,
 design_name text not null check (char_length(design_name) between 1 and 160), details text not null check (char_length(details) between 1 and 3000),
 status text not null default 'New' check (status in ('New','Responded','Closed')), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.website_inquiries (
 id uuid primary key default gen_random_uuid(), client_id uuid not null references public.client_profiles(user_id) on delete cascade,
 website_type text not null, website_name text not null check (char_length(website_name) between 1 and 160), details text not null check (char_length(details) between 1 and 5000),
 status text not null default 'New' check (status in ('New','Responded','Closed')), created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table if not exists public.design_inquiry_files (
 id uuid primary key default gen_random_uuid(), inquiry_id uuid not null references public.design_inquiries(id) on delete cascade,
 file_name text not null, storage_path text not null, created_at timestamptz not null default now()
);
create table if not exists public.site_services (
 id uuid primary key default gen_random_uuid(), name text not null unique, description text not null default '', price text not null default '', icon text not null default '✦', is_active boolean not null default true, sort_order integer not null default 10, created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
insert into public.site_services(name,description,price,icon,sort_order) values
('Logo Design','Distinctive logo concepts to give your business a memorable visual identity.','','✳',10),
('Flyer Design','Professional promotional flyers for events, sales, launches, businesses and announcements.','','▤',20),
('Poster Design','Eye-catching poster designs for events, promotions, campaigns, launches and announcements.','','▥',30),
('Business Card Design','Professional business card designs that help your brand make a lasting impression.','','▧',40),
('Social Media Design','Branded posts, covers and promotional graphics for your social media pages.','','◎',50),
('Certificate Design','Clean, polished certificates for recognition, achievements and special occasions.','','✦',60),
('Banner Design','Large-format banners for businesses, events, promotions and outdoor displays.','','▰',70),
('Other','Have another design idea? Ask us about a custom design.','','◆',80)
on conflict(name) do update set description=excluded.description,icon=excluded.icon,sort_order=excluded.sort_order,is_active=true,updated_at=now();
insert into public.site_services(name,description,price,icon,sort_order) values ('OX-AI Website','Modern AI-powered website built for your business, brand or idea.','JMD $50,000','✦',90) on conflict(name) do update set description=excluded.description,price=excluded.price,is_active=true,updated_at=now();
alter table public.design_inquiries enable row level security; alter table public.website_inquiries enable row level security; alter table public.design_inquiry_files enable row level security; alter table public.site_services enable row level security;
drop policy if exists "design inquiries own read" on public.design_inquiries; create policy "design inquiries own read" on public.design_inquiries for select using (client_id=auth.uid() or public.is_ox_admin());
drop policy if exists "design inquiries own insert" on public.design_inquiries; create policy "design inquiries own insert" on public.design_inquiries for insert with check (client_id=auth.uid());
drop policy if exists "design inquiries admin update" on public.design_inquiries; create policy "design inquiries admin update" on public.design_inquiries for update using (public.is_ox_admin()) with check (public.is_ox_admin());
drop policy if exists "website inquiries own read" on public.website_inquiries; create policy "website inquiries own read" on public.website_inquiries for select using (client_id=auth.uid() or public.is_ox_admin());
drop policy if exists "website inquiries own insert" on public.website_inquiries; create policy "website inquiries own insert" on public.website_inquiries for insert with check (client_id=auth.uid());
drop policy if exists "website inquiries admin update" on public.website_inquiries; create policy "website inquiries admin update" on public.website_inquiries for update using (public.is_ox_admin()) with check (public.is_ox_admin());
drop policy if exists "inquiry files own read" on public.design_inquiry_files; create policy "inquiry files own read" on public.design_inquiry_files for select using (exists(select 1 from public.design_inquiries d where d.id=inquiry_id and (d.client_id=auth.uid() or public.is_ox_admin())));
drop policy if exists "inquiry files own insert" on public.design_inquiry_files; create policy "inquiry files own insert" on public.design_inquiry_files for insert with check (exists(select 1 from public.design_inquiries d where d.id=inquiry_id and d.client_id=auth.uid()));
drop policy if exists "services public read" on public.site_services; create policy "services public read" on public.site_services for select using (is_active=true or public.is_ox_admin());
drop policy if exists "services admin insert" on public.site_services; create policy "services admin insert" on public.site_services for insert with check (public.is_ox_admin());
drop policy if exists "services admin update" on public.site_services; create policy "services admin update" on public.site_services for update using (public.is_ox_admin()) with check (public.is_ox_admin());
drop policy if exists "services admin delete" on public.site_services; create policy "services admin delete" on public.site_services for delete using (public.is_ox_admin());
-- Storage policy for optional inquiry attachments, reusing existing client-projects bucket.
drop policy if exists "inquiry attachments upload" on storage.objects; create policy "inquiry attachments upload" on storage.objects for insert to authenticated with check (bucket_id='client-projects' and (storage.foldername(name))[1]=auth.uid()::text);
drop policy if exists "inquiry attachments admin read" on storage.objects; create policy "inquiry attachments admin read" on storage.objects for select to authenticated using (bucket_id='client-projects' and (public.is_ox_admin() or (storage.foldername(name))[1]=auth.uid()::text));
