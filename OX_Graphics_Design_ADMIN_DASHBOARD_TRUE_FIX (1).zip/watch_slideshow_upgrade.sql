-- OX Graphics Design Watch Slideshow: images and videos managed by admins
create table if not exists public.watch_slides (
  id uuid primary key default gen_random_uuid(),
  title text not null default 'OX Graphics Design',
  media_url text not null,
  media_type text not null check (media_type in ('image','video')),
  storage_path text,
  sort_order integer not null default 0,
  is_published boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.watch_slides enable row level security;
grant select on public.watch_slides to anon, authenticated;
grant insert, update, delete on public.watch_slides to authenticated;

drop policy if exists "Anyone can view published watch slides" on public.watch_slides;
create policy "Anyone can view published watch slides" on public.watch_slides
for select to anon, authenticated using (is_published = true or public.is_ox_admin());

drop policy if exists "Admins can insert watch slides" on public.watch_slides;
create policy "Admins can insert watch slides" on public.watch_slides
for insert to authenticated with check (public.is_ox_admin());

drop policy if exists "Admins can update watch slides" on public.watch_slides;
create policy "Admins can update watch slides" on public.watch_slides
for update to authenticated using (public.is_ox_admin()) with check (public.is_ox_admin());

drop policy if exists "Admins can delete watch slides" on public.watch_slides;
create policy "Admins can delete watch slides" on public.watch_slides
for delete to authenticated using (public.is_ox_admin());

insert into storage.buckets (id, name, public)
values ('watch-media','watch-media',true)
on conflict (id) do update set public=true;

drop policy if exists "Public can view watch media" on storage.objects;
create policy "Public can view watch media" on storage.objects
for select using (bucket_id = 'watch-media');

drop policy if exists "Admins can upload watch media" on storage.objects;
create policy "Admins can upload watch media" on storage.objects
for insert to authenticated with check (bucket_id = 'watch-media' and public.is_ox_admin());

drop policy if exists "Admins can update watch media" on storage.objects;
create policy "Admins can update watch media" on storage.objects
for update to authenticated using (bucket_id = 'watch-media' and public.is_ox_admin()) with check (bucket_id = 'watch-media' and public.is_ox_admin());

drop policy if exists "Admins can delete watch media" on storage.objects;
create policy "Admins can delete watch media" on storage.objects
for delete to authenticated using (bucket_id = 'watch-media' and public.is_ox_admin());
