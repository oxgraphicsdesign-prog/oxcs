-- OX Graphics Design portfolio backend (Supabase / PostgreSQL)
-- Run this in Supabase Dashboard > SQL Editor.
-- Create an account in Supabase first, then run this script.

create extension if not exists pgcrypto;

create table if not exists public.portfolio_projects (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 120),
  category text not null default 'Other',
  description text not null default '',
  image_url text not null,
  storage_path text,
  is_published boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.site_admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.portfolio_projects enable row level security;
alter table public.site_admins enable row level security;

create or replace function public.is_ox_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.site_admins
    where user_id = (select auth.uid())
  );
$$;

revoke all on function public.is_ox_admin() from public;
grant execute on function public.is_ox_admin() to authenticated, anon;

-- Anyone can see published portfolio items. Only listed admins can manage them.
drop policy if exists "Public can view published portfolio" on public.portfolio_projects;
create policy "Public can view published portfolio"
on public.portfolio_projects for select
to anon, authenticated
using (is_published = true or public.is_ox_admin());

drop policy if exists "Admins can insert portfolio" on public.portfolio_projects;
create policy "Admins can insert portfolio"
on public.portfolio_projects for insert
to authenticated
with check (public.is_ox_admin());

drop policy if exists "Admins can update portfolio" on public.portfolio_projects;
create policy "Admins can update portfolio"
on public.portfolio_projects for update
to authenticated
using (public.is_ox_admin())
with check (public.is_ox_admin());

drop policy if exists "Admins can delete portfolio" on public.portfolio_projects;
create policy "Admins can delete portfolio"
on public.portfolio_projects for delete
to authenticated
using (public.is_ox_admin());

-- Public image bucket for portfolio thumbnails.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('portfolio', 'portfolio', true, null, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update
set public = true, file_size_limit = null,
    allowed_mime_types = array['image/jpeg','image/png','image/webp'];

drop policy if exists "Public can view portfolio images" on storage.objects;
create policy "Public can view portfolio images"
on storage.objects for select
to anon, authenticated
using (bucket_id = 'portfolio');

drop policy if exists "Admins can upload portfolio images" on storage.objects;
create policy "Admins can upload portfolio images"
on storage.objects for insert
to authenticated
with check (bucket_id = 'portfolio' and public.is_ox_admin());

drop policy if exists "Admins can update portfolio images" on storage.objects;
create policy "Admins can update portfolio images"
on storage.objects for update
to authenticated
using (bucket_id = 'portfolio' and public.is_ox_admin())
with check (bucket_id = 'portfolio' and public.is_ox_admin());

drop policy if exists "Admins can delete portfolio images" on storage.objects;
create policy "Admins can delete portfolio images"
on storage.objects for delete
to authenticated
using (bucket_id = 'portfolio' and public.is_ox_admin());

-- After creating your account via the Supabase Auth dashboard or admin page,
-- copy that user's UUID from Authentication > Users, then run:
-- insert into public.site_admins (user_id) values ('PASTE-AUTH-USER-UUID-HERE');
