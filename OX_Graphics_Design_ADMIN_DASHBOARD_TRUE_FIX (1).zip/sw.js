const CACHE='ox-graphics-adminfix12';
const SHELL=['./','./index.html','./common.css','./app-v7.js?v=12','./pwa.js','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png'];
const timeout=(p,ms)=>Promise.race([p,new Promise((_,rej)=>setTimeout(()=>rej(new Error('network timeout')),ms))]);
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(SHELL)).then(()=>self.skipWaiting())));
self.addEventListener('activate',event=>event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',event=>{
 const request=event.request; if(request.method!=='GET')return; const url=new URL(request.url); if(url.origin!==location.origin)return;
 if(request.mode==='navigate'){
   event.respondWith(timeout(fetch(request),8000).then(response=>{if(response.ok)caches.open(CACHE).then(c=>c.put(request,response.clone()));return response}).catch(()=>{
     const path=url.pathname.split('/').pop()||'index.html';
     const isAdmin=path.startsWith('admin');
     if(isAdmin) return new Response('<!doctype html><title>Admin page unavailable</title><h1>Admin page unavailable</h1><p>Please reconnect and reload this admin page.</p>',{status:503,headers:{'Content-Type':'text/html'}});
     return caches.match(request).then(c=>c||caches.match('./index.html'));
   })); return;
 }
 event.respondWith(caches.match(request).then(cached=>cached||timeout(fetch(request),8000).then(response=>{if(response.ok)caches.open(CACHE).then(c=>c.put(request,response.clone()));return response})));
});