-- OX Graphics Design client portal upgrade
-- Run in Supabase Dashboard > SQL Editor AFTER the existing portfolio schema.
-- Uses Supabase Auth email/password. Never put a service-role key in website code.

create table if not exists public.client_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  whatsapp text not null default '',
  email text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.handle_new_client()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.client_profiles (user_id, full_name, whatsapp, email)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce(new.raw_user_meta_data ->> 'whatsapp', ''),
    coalesce(new.email, '')
  )
  on conflict (user_id) do update set
    full_name = excluded.full_name,
    whatsapp = excluded.whatsapp,
    email = excluded.email,
    updated_at = now();
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_client_profile on auth.users;
create trigger on_auth_user_created_client_profile
after insert on auth.users
for each row execute procedure public.handle_new_client();

create table if not exists public.project_requests (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.client_profiles(user_id) on delete cascade,
  title text not null check (char_length(title) between 1 and 120),
  service text not null,
  details text not null,
  status text not null default 'Submitted'
    check (status in ('Submitted','In progress','Waiting for client','Completed','Cancelled')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.project_files (
  id uuid primary key default gen_random_uuid(),
  request_id uuid not null references public.project_requests(id) on delete cascade,
  file_name text not null,
  storage_path text not null unique,
  file_kind text not null check (file_kind in ('reference','deliverable')),
  created_at timestamptz not null default now()
);

alter table public.client_profiles enable row level security;
alter table public.project_requests enable row level security;
alter table public.project_files enable row level security;

grant select, update on public.client_profiles to authenticated;
grant select, insert on public.project_requests to authenticated;
grant update on public.project_requests to authenticated;
grant select, insert on public.project_files to authenticated;

-- Clients can read/update their own profile; admins can read all profiles.
drop policy if exists "Clients and admins can read client profiles" on public.client_profiles;
create policy "Clients and admins can read client profiles"
on public.client_profiles for select to authenticated
using (user_id = (select auth.uid()) or public.is_ox_admin());
drop policy if exists "Clients can update own profile" on public.client_profiles;
create policy "Clients can update own profile"
on public.client_profiles for update to authenticated
using (user_id = (select auth.uid()))
with check (user_id = (select auth.uid()));

-- Each client can create and read only their own requests. Only admins can change status.
drop policy if exists "Clients and admins can read project requests" on public.project_requests;
create policy "Clients and admins can read project requests"
on public.project_requests for select to authenticated
using (client_id = (select auth.uid()) or public.is_ox_admin());
drop policy if exists "Clients can create own project requests" on public.project_requests;
create policy "Clients can create own project requests"
on public.project_requests for insert to authenticated
with check (client_id = (select auth.uid()));
drop policy if exists "Admins can update project requests" on public.project_requests;
create policy "Admins can update project requests"
on public.project_requests for update to authenticated
using (public.is_ox_admin()) with check (public.is_ox_admin());
drop policy if exists "Admins can delete project requests" on public.project_requests;
create policy "Admins can delete project requests"
on public.project_requests for delete to authenticated
using (public.is_ox_admin());

-- Clients can see files for their own requests. Clients may add reference files only;
-- admins may add completed deliverables and manage file records.
drop policy if exists "Clients and admins can read project files" on public.project_files;
create policy "Clients and admins can read project files"
on public.project_files for select to authenticated
using (
  public.is_ox_admin() or exists (
    select 1 from public.project_requests r
    where r.id = request_id and r.client_id = (select auth.uid())
  )
);
drop policy if exists "Clients can attach reference files to own requests" on public.project_files;
create policy "Clients can attach reference files to own requests"
on public.project_files for insert to authenticated
with check (
  file_kind = 'reference' and exists (
    select 1 from public.project_requests r
    where r.id = request_id and r.client_id = (select auth.uid())
  )
);
drop policy if exists "Admins can add deliverable files" on public.project_files;
create policy "Admins can add deliverable files"
on public.project_files for insert to authenticated
with check (public.is_ox_admin());
drop policy if exists "Admins can delete project file records" on public.project_files;
create policy "Admins can delete project file records"
on public.project_files for delete to authenticated
using (public.is_ox_admin());

-- Private bucket for client references and completed designs.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('client-projects', 'client-projects', false, 26214400,
        array['image/jpeg','image/png','image/webp','application/pdf'])
on conflict (id) do update set
  public = false,
  file_size_limit = 26214400,
  allowed_mime_types = array['image/jpeg','image/png','image/webp','application/pdf'];

-- Client reference path format: <auth-user-uuid>/<request-uuid>/<filename>
drop policy if exists "Clients upload references to own folder" on storage.objects;
create policy "Clients upload references to own folder"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'client-projects'
  and split_part(name, '/', 1) = (select auth.uid())::text
  and exists (
    select 1 from public.project_requests r
    where r.id::text = split_part(name, '/', 2)
      and r.client_id = (select auth.uid())
  )
);

-- Admins upload completed files under <request-uuid>/<filename>.
drop policy if exists "Admins upload client deliverables" on storage.objects;
create policy "Admins upload client deliverables"
on storage.objects for insert to authenticated
with check (
  bucket_id = 'client-projects' and public.is_ox_admin()
);
drop policy if exists "Admins update client project files" on storage.objects;
create policy "Admins update client project files"
on storage.objects for update to authenticated
using (bucket_id = 'client-projects' and public.is_ox_admin())
with check (bucket_id = 'client-projects' and public.is_ox_admin());
drop policy if exists "Admins delete client project files" on storage.objects;
create policy "Admins delete client project files"
on storage.objects for delete to authenticated
using (bucket_id = 'client-projects' and public.is_ox_admin());

-- Signed downloads are created only after project_files RLS authorizes the record.
-- Storage reads are allowed to the owner of a referenced file or to an admin.
drop policy if exists "Owners and admins can download client project files" on storage.objects;
create policy "Owners and admins can download client project files"
on storage.objects for select to authenticated
using (
  bucket_id = 'client-projects' and (
    public.is_ox_admin() or exists (
      select 1
      from public.project_files f
      join public.project_requests r on r.id = f.request_id
      where f.storage_path = name and r.client_id = (select auth.uid())
    )
  )
);


-- FIX: ensure project_requests.client_id references the same auth UUID stored
-- in client_profiles.user_id. This repairs installations where an older version
-- accidentally pointed the foreign key at a different profile column/table.
alter table public.project_requests
  drop constraint if exists project_requests_client_id_fkey;

-- Backfill profiles for existing Auth users (including accounts created before
-- the profile trigger was installed).
insert into public.client_profiles (user_id, full_name, whatsapp, email)
select u.id,
       coalesce(u.raw_user_meta_data ->> 'full_name', ''),
       coalesce(u.raw_user_meta_data ->> 'whatsapp', ''),
       coalesce(u.email, '')
from auth.users u
on conflict (user_id) do update set
  full_name = case when public.client_profiles.full_name = '' then excluded.full_name else public.client_profiles.full_name end,
  whatsapp = case when public.client_profiles.whatsapp = '' then excluded.whatsapp else public.client_profiles.whatsapp end,
  email = case when public.client_profiles.email = '' then excluded.email else public.client_profiles.email end,
  updated_at = now();

-- Add the intended FK after profile backfill. If there are already orphaned
-- request rows, PostgreSQL will report them instead of silently deleting data.
alter table public.project_requests
  add constraint project_requests_client_id_fkey
  foreign key (client_id) references public.client_profiles(user_id) on delete cascade;

-- Remove the bucket-specific file-size cap for portfolio and client project
-- uploads. Supabase's project-level/global upload limit still applies.
update storage.buckets
set file_size_limit = null
where id in ('portfolio', 'client-projects');
