-- OX Graphics Design: likes, ratings and comments for portfolio designs
create table if not exists public.design_likes (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.portfolio_projects(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (project_id, user_id)
);

create table if not exists public.design_reviews (
  id uuid primary key default gen_random_uuid(),
  project_id uuid not null references public.portfolio_projects(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  rating integer not null check (rating between 1 and 5),
  comment text not null default '' check (char_length(comment) <= 1000),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (project_id, user_id)
);

alter table public.design_likes enable row level security;
alter table public.design_reviews enable row level security;

grant select on public.design_likes to anon, authenticated;
grant insert, delete on public.design_likes to authenticated;
grant select on public.design_reviews to anon, authenticated;
grant insert, update, delete on public.design_reviews to authenticated;

drop policy if exists "Anyone can view likes on published designs" on public.design_likes;
create policy "Anyone can view likes on published designs"
on public.design_likes for select to anon, authenticated
using (exists (select 1 from public.portfolio_projects p where p.id = project_id and p.is_published = true));

drop policy if exists "Users can like published designs" on public.design_likes;
create policy "Users can like published designs"
on public.design_likes for insert to authenticated
with check (user_id = (select auth.uid()) and exists (select 1 from public.portfolio_projects p where p.id = project_id and p.is_published = true));

drop policy if exists "Users can remove their likes" on public.design_likes;
create policy "Users can remove their likes"
on public.design_likes for delete to authenticated
using (user_id = (select auth.uid()) or public.is_ox_admin());

drop policy if exists "Anyone can view reviews on published designs" on public.design_reviews;
create policy "Anyone can view reviews on published designs"
on public.design_reviews for select to anon, authenticated
using (exists (select 1 from public.portfolio_projects p where p.id = project_id and p.is_published = true));

drop policy if exists "Users can review published designs" on public.design_reviews;
create policy "Users can review published designs"
on public.design_reviews for insert to authenticated
with check (user_id = (select auth.uid()) and exists (select 1 from public.portfolio_projects p where p.id = project_id and p.is_published = true));

drop policy if exists "Users can update their reviews" on public.design_reviews;
create policy "Users can update their reviews"
on public.design_reviews for update to authenticated
using (user_id = (select auth.uid()) or public.is_ox_admin())
with check (user_id = (select auth.uid()) or public.is_ox_admin());

drop policy if exists "Users and admins can delete reviews" on public.design_reviews;
create policy "Users and admins can delete reviews"
on public.design_reviews for delete to authenticated
using (user_id = (select auth.uid()) or public.is_ox_admin());

-- Optional new service setting. Existing value is preserved if already customized.
insert into public.site_settings (key, value)
values ('ox_ai_price', 'JMD $50,000'), ('ox_ai_service_name', 'OX-AI Website')
on conflict (key) do nothing;
