(function(){
  if('serviceWorker' in navigator){
    window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(err=>console.warn('PWA service worker:',err)));
  }
  let deferredPrompt=null;
  window.addEventListener('beforeinstallprompt',e=>{
    e.preventDefault(); deferredPrompt=e;
    document.querySelectorAll('[data-install-app]').forEach(b=>b.hidden=false);
  });
  window.addEventListener('appinstalled',()=>{
    deferredPrompt=null;
    document.querySelectorAll('[data-install-app]').forEach(b=>{b.hidden=true});
  });
  document.addEventListener('click',async e=>{
    const btn=e.target.closest?.('[data-install-app]');
    if(!btn)return;
    if(deferredPrompt){deferredPrompt.prompt(); await deferredPrompt.userChoice; deferredPrompt=null; return;}
    alert('To install OX Graphics as an app: use your browser menu and choose “Install app” or “Add to Home screen.”');
  });
})();
