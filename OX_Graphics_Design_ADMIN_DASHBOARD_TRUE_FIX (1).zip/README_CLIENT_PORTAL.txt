OX GRAPHICS DESIGN — WEBSITE + CLIENT PORTAL

NEW IN THIS VERSION
- Create Account, Login, and Request a Project are separate pages.
- Portfolio images are clickable and open in a large full-screen viewer with the complete image visible.
- Admin is split into Dashboard, Portfolio Designs, Client Requests, Upload Design, Website Editor, and Profile.
- Admin pages use selected navigation buttons for the current section.
- Admin can upload portfolio designs and client deliverables.
- Admin Website Editor can change logo, hero/banner image, hero text, price text, about text, footer text, contact details and policies.
- Admin can create/edit/delete custom public pages.
- Terms & Conditions, Privacy Policy and Payment Policy are included.
- Payment policy defaults to: 50% is paid before the project starts; the 50% deposit is non-refundable; remaining 50% is due before final delivery.
- Portfolio and client-project bucket file_size_limit is removed at the bucket level. Supabase/project-level upload limits still apply.

SETUP
1. Keep your existing Supabase schema and client portal upgrade already installed.
2. Run cms_upgrade.sql in Supabase SQL Editor.
3. Make sure your admin Auth user UUID exists in public.site_admins.
4. Open index.html or deploy the folder to your hosting.
5. Use admin.html for the admin control panel.

IMPORTANT
- Never put a Supabase service-role key in these files.
- The public anon/publishable key is used in the browser and database RLS controls access.
- Replace the default policy wording in Website Editor with your final business/legal wording if needed.
