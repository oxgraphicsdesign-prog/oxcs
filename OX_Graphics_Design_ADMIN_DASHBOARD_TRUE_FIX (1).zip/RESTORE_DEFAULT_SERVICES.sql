-- OX Graphics Design: restore the standard public services.
-- Run this in Supabase SQL Editor once. It does not remove custom services.
insert into public.site_services(name,description,price,icon,sort_order) values
('Logo Design','Distinctive logo concepts to give your business a memorable visual identity.','','✳',10),
('Flyer Design','Professional promotional flyers for events, sales, launches, businesses and announcements.','','▤',20),
('Poster Design','Eye-catching poster designs for events, promotions, campaigns, launches and announcements.','','▥',30),
('Business Card Design','Professional business card designs that help your brand make a lasting impression.','','▧',40),
('Social Media Design','Branded posts, covers and promotional graphics for your social media pages.','','◎',50),
('Certificate Design','Clean, polished certificates for recognition, achievements and special occasions.','','✦',60),
('Banner Design','Large-format banners for businesses, events, promotions and outdoor displays.','','▰',70),
('Other','Have another design idea? Ask us about a custom design.','','◆',80),
('OX-AI Website','Modern AI-powered website built for your business, brand or idea.','JMD $50,000','✦',90)
on conflict(name) do update set description=excluded.description,price=excluded.price,icon=excluded.icon,sort_order=excluded.sort_order,is_active=true,updated_at=now();
