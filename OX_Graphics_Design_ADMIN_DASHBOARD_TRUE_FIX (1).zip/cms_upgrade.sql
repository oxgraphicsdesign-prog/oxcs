-- OX Graphics Design CMS / policies / admin navigation upgrade
create table if not exists public.site_settings (
  key text primary key,
  value text not null default '',
  updated_at timestamptz not null default now()
);

create table if not exists public.site_pages (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  content text not null default '',
  is_published boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.site_settings enable row level security;
alter table public.site_pages enable row level security;
grant select on public.site_settings, public.site_pages to anon, authenticated;
grant insert, update, delete on public.site_settings, public.site_pages to authenticated;

drop policy if exists "Public can read site settings" on public.site_settings;
create policy "Public can read site settings" on public.site_settings for select to anon, authenticated using (true);
drop policy if exists "Admins manage site settings" on public.site_settings;
create policy "Admins manage site settings" on public.site_settings for all to authenticated using (public.is_ox_admin()) with check (public.is_ox_admin());

drop policy if exists "Public can read published pages" on public.site_pages;
create policy "Public can read published pages" on public.site_pages for select to anon, authenticated using (is_published = true or public.is_ox_admin());
drop policy if exists "Admins manage site pages" on public.site_pages;
create policy "Admins manage site pages" on public.site_pages for all to authenticated using (public.is_ox_admin()) with check (public.is_ox_admin());

insert into public.site_settings(key,value) values
('site_name','OX Graphics Design'),
('tagline','Creative that stands out.'),
('logo_url',''),
('hero_title','Design that makes your brand stand out.'),
('hero_text','Creative graphic design for brands, businesses, events and special occasions.'),
('hero_image_url',''),
('price','JMD $1,500 per design'),
('about_title','We make your ideas look the part.'),
('about_text','At OX Graphics Design, we believe great design does more than look good — it helps people notice, remember and connect with your brand.'),
('contact_whatsapp',''),
('contact_email',''),
('footer_text','Creative that stands out.'),
('payment_policy','50% of the project fee must be paid before the project starts. The 50% deposit is non-refundable. The remaining 50% is due before final delivery.'),
('terms','By requesting a project, you agree to provide accurate project information, review proofs promptly, and pay the agreed fees on time. Work begins after the required deposit is received.'),
('privacy','We use the information you submit to communicate about your projects, process requests, and provide completed files. We do not intentionally sell your personal information.'),
('custom_sections','')
on conflict (key) do nothing;

insert into public.site_pages(slug,title,content,is_published) values
('terms-and-conditions','Terms & Conditions','',true),
('privacy-policy','Privacy Policy','',true),
('payment-policy','Payment Policy','',true)
on conflict (slug) do nothing;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values('site-assets','site-assets',true,null,array['image/jpeg','image/png','image/webp','image/svg+xml'])
on conflict(id) do update set public=true,file_size_limit=null;

drop policy if exists "Public can view site assets" on storage.objects;
create policy "Public can view site assets" on storage.objects for select to anon, authenticated using(bucket_id='site-assets');
drop policy if exists "Admins upload site assets" on storage.objects;
create policy "Admins upload site assets" on storage.objects for insert to authenticated with check(bucket_id='site-assets' and public.is_ox_admin());
drop policy if exists "Admins update site assets" on storage.objects;
create policy "Admins update site assets" on storage.objects for update to authenticated using(bucket_id='site-assets' and public.is_ox_admin()) with check(bucket_id='site-assets' and public.is_ox_admin());
drop policy if exists "Admins delete site assets" on storage.objects;
create policy "Admins delete site assets" on storage.objects for delete to authenticated using(bucket_id='site-assets' and public.is_ox_admin());
