const SUPABASE_URL='https://xzzsbpdqibsnqruhayvx.supabase.co';
const SUPABASE_ANON_KEY='sb_publishable_w4jldjxgVTYG_ndaXkNFeg_oNLEGq34';
const db=supabase.createClient(SUPABASE_URL,SUPABASE_ANON_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true,storage:window.localStorage,storageKey:'ox-graphics-auth-v2'}});
let authSession=null;
let authReady=null;
let authInitStarted=false;
function refreshAuth(){
  if(authReady) return authReady;
  authInitStarted=true;
  const session=db.auth.getSession().then(({data})=>data?.session||null).catch(e=>{console.warn('Auth session load failed:',e);return null;});
  authReady=session.then(s=>{
    authSession=s||null;
    if(document.readyState!=='loading') renderAuthUI(authSession?.user||null);
    return authSession;
  });
  return authReady;
}
function startAuth(){
  refreshAuth();
  db.auth.onAuthStateChange((_event,session)=>{
    authSession=session||null;
    if(document.readyState!=='loading') renderAuthUI(authSession?.user||null);
  });
}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',startAuth,{once:true}); else startAuth();
const $=id=>document.getElementById(id); const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function user(){const s=await refreshAuth(); return s?.user||null}
async function isAdmin(){const u=await user(); if(!u)return false; const {data,error}=await db.rpc('is_ox_admin'); if(error){console.warn('Admin check failed:',error); return false} return data===true;}
function msg(id,t){if($(id)){ $(id).textContent=t; $(id).classList.remove('hidden'); }}
async function requireAdmin(){if(!(await isAdmin())){location.href='login.html?admin=1';return false}return true}
async function signOut(){await db.auth.signOut();location.href='index.html'}
function adminNav(active){const links=[['admin-dashboard.html','Dashboard','dashboard'],['admin-portfolio.html','Portfolio Designs','portfolio'],['admin-requests.html','Client Requests','requests'],['admin-design-inquiries.html','Design Inquiries','design-inquiries'],['admin-website-inquiries.html','OX-AI Websites','website-inquiries'],['admin-services.html','Services','services'],['admin-upload.html','Upload Design','upload'],['admin-watch.html','Watch Slideshow','watch'],['admin-editor.html','Website Editor','editor'],['admin-profile.html','Profile','profile']];return `<div class="admin-nav">${links.map(x=>`<a class="${active===x[2]?'active':''}" href="${x[0]}">${x[1]}</a>`).join('')}<a href="index.html">View Website</a><a href="#" id="signout">Sign Out</a></div>`}
function adminShell(active,title,body){document.write(`<header class="topbar"><div class="wrap nav"><a class="brand" href="admin-dashboard.html">OX GRAPHICS DESIGN<small>ADMIN CONTROL PANEL</small></a></div></header><main class="wrap page"><h1>${title}</h1>${adminNav(active)}${body}</main>`);setTimeout(()=>$('signout')?.addEventListener('click',e=>{e.preventDefault();signOut()}),0)}
async function publicSettings(){const {data}=await db.from('site_settings').select('key,value');return Object.fromEntries((data||[]).map(x=>[x.key,x.value]))}
async function loadPublicNav(){const s=await publicSettings(); document.querySelectorAll('[data-setting]').forEach(el=>{const k=el.dataset.setting;if(s[k]!=null){if(el.tagName==='IMG')el.src=s[k];else el.textContent=s[k]}});return s}
async function uploadPublicAsset(file){const path=`${Date.now()}-${crypto.randomUUID()}-${file.name.toLowerCase().replace(/[^a-z0-9._-]+/g,'-')}`;const {error}=await db.storage.from('site-assets').upload(path,file,{contentType:file.type,upsert:false});if(error)throw error;return db.storage.from('site-assets').getPublicUrl(path).data.publicUrl}
async function saveSetting(key,value){return db.from('site_settings').upsert({key,value,updated_at:new Date().toISOString()})}
async function openImage(url,title){const m=$('imageModal');if(!m)return; $('modalImage').src=url;$('modalTitle').textContent=title||'';m.classList.add('open');document.body.style.overflow='hidden'}
function closeImage(){const m=$('imageModal');if(m)m.classList.remove('open');document.body.style.overflow=''}
async function initAuthUI(){return refreshAuth()}
function renderAuthUI(u){
  document.querySelectorAll('.navlinks').forEach(nav=>{
    // Keep all non-auth navigation exactly as authored; only replace the auth controls.
    nav.querySelectorAll('[data-auth-control]').forEach(el=>el.remove());
    [...nav.querySelectorAll('a')].forEach(a=>{
      const href=(a.getAttribute('href')||'').toLowerCase().split('?')[0].split('#')[0];
      const text=(a.textContent||'').trim().toLowerCase().replace(/\s+/g,' ');
      const guest = href.endsWith('/create-account.html') || href.endsWith('create-account.html') ||
                    href.endsWith('/login.html') || href.endsWith('login.html') ||
                    text==='create account' || text==='login';
      if(guest) a.remove();
    });

    const make=(label,href,kind,handler)=>{
      const a=document.createElement('a');
      a.dataset.authControl='1';
      a.dataset.authKind=kind;
      a.href=href;
      a.textContent=label;
      if(handler) a.addEventListener('click',handler,{once:false});
      return a;
    };
    if(u){
      nav.appendChild(make('My Account','request-project.html','account'));
      nav.appendChild(make('Sign Out','#','signout',async e=>{e.preventDefault();await signOut();}));
    }else{
      nav.appendChild(make('Login','login.html','login'));
      nav.appendChild(make('Create Account','create-account.html','create'));
    }
  });
}

async function currentUser(){return await user()}
async function getDesignStats(projectId){
  const likes=await db.from('design_likes').select('id',{count:'exact',head:true}).eq('project_id',projectId);
  const me=await currentUser();
  let liked=false;
  if(me){const l=await db.from('design_likes').select('id').eq('project_id',projectId).eq('user_id',me.id).maybeSingle(); liked=!!l.data;}
  return {likes:likes.count||0,liked};
}
async function toggleDesignLike(projectId){
  const u=await currentUser(); if(!u){location.href='login.html';return null}
  const existing=await db.from('design_likes').select('id').eq('project_id',projectId).eq('user_id',u.id).maybeSingle();
  if(existing.data) await db.from('design_likes').delete().eq('id',existing.data.id); else {const r=await db.from('design_likes').insert({project_id:projectId,user_id:u.id}); if(r.error) throw r.error;}
  return getDesignStats(projectId);
}

async function loadServices(targetId, includeBlank=true){
  const el=$(targetId); if(!el)return [];
  const r=await Promise.race([db.from('site_services').select('id,name,description,price,icon,is_active,sort_order').eq('is_active',true).order('sort_order',{ascending:true}).order('created_at',{ascending:true}),new Promise(r=>setTimeout(()=>r({data:[],error:{message:'timeout'}}),2500))]);
  if(r.error){console.warn('Services unavailable:',r.error);return []}
  const rows=r.data||[];
  if(el.tagName==='SELECT'){
    el.innerHTML=(includeBlank?'<option value="">Choose a service</option>':'')+rows.map(x=>`<option value="${esc(x.name)}">${esc(x.name)}${x.price?` — ${esc(x.price)}`:''}</option>`).join('');
  } else {
    el.innerHTML=rows.map(x=>`<article class="service"><div class="service-icon">${esc(x.icon||'✦')}</div><h3>${esc(x.name)}</h3><p>${esc(x.description||'')}</p>${x.price?`<strong style="display:block;margin-top:16px">${esc(x.price)}</strong>`:''}<a class="arrow" href="${x.name.toLowerCase().includes('ai')?'website-request.html':'request-project.html'}">${x.name.toLowerCase().includes('ai')?'Tell us about your website':'Order '+esc(x.name)} ↗</a></article>`).join('');
  }
  return rows;
}
